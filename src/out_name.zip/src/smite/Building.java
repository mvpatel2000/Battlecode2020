package smite;

import battlecode.common.*;

public abstract class Building extends Robot {

    public Building(RobotController rc) throws GameActionException {
        super(rc);
    }

    @Override
    public void run() throws GameActionException {

    }
}
