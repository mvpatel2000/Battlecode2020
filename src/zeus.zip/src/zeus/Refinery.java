package zeus;

import battlecode.common.*;

public class Refinery extends Building {

    public Refinery(RobotController rc) throws GameActionException {
        super(rc);
    }

    @Override
    public void run() throws GameActionException {
        super.run();
    }
}
